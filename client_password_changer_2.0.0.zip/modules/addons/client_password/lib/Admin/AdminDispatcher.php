<?php

namespace WHMCS\Module\Addon\ClientPassword\Admin;

class AdminDispatcher
{
    public function dispatch($action, $params): string
    {
        if (!$action) {
            $action = 'index';
        }

        $controller = new Controller();
        if (is_callable([$controller, $action])) {
            return $controller->$action($params);
        }

        return '<p>Invalid action requested. Please go back and try again.</p>';
    }
}