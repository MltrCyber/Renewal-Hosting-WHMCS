<?php

namespace WHMCS\Module\Addon\ClientPassword\Admin;

use Exception;
use WHMCS\User\User;
use WHMCS\Module\Addon\ClientPassword\Helpers\CsrfHelper;

class Controller
{
    public function index(): string
    {
        return '<p>Client/User passwords can be changed from the <b>Users</b> tab on the client\'s summary or under <b>Clients > Manage Users</b></p>';
    }

    public function data($params): void
    {
        if (empty($_POST['user'])) {
            $this->handleReturn(['status' => 'error', 'description' => 'No user id provided.']);
        }

        if (empty($_POST['csrfToken']) || !CsrfHelper::verify($params['csrfKey'], $_POST['csrfToken'])) {
            $this->handleReturn(['status' => 'error', 'description' => 'Invalid CSRF token provided.']);
        }

        try {
            $userData = User::findOrFail($_POST['user']);

            $this->handleReturn([
                'status'    => 'success',
                'data'      => [
                    'fullName'  => $userData->fullName,
                    'email'     => $userData->email,
                ],
            ]);
        } catch (Exception $e) {
            $this->handleReturn([
                'status'        => 'error',
                'description'   => 'Unable to fetch user data, please try again.',
            ]);
        }
    }

    public function change($params): void
    {
        if (empty($_POST['user'])) {
            $this->handleReturn(['status' => 'error', 'description' => 'No user id provided.']);
        }

        if (empty($_POST['csrfToken']) || !CsrfHelper::verify($params['csrfKey'], $_POST['csrfToken'])) {
            $this->handleReturn(['status' => 'error', 'description' => 'Invalid CSRF token provided.']);
        }

        if (empty($_POST['password'])) {
            $this->handleReturn([
                'status'        => 'error',
                'description'   => 'No password provided.',
            ]);
        }

        try {
            $user = User::findOrFail($_POST['user']);
            $user->updatePassword( $_POST['password']);

            if ($params['enableLogging']) {
                foreach ($user->ownedClients() as $client) {
                    logActivity('User password manually changed by admin (User ID: ' . $user->id . ')', $client->id);
                }
            }
        } catch (Exception $e) {
            $this->handleReturn([
                'status'        => 'error',
                'description'   => 'Unable to update password, please try again.',
            ]);
        }

        $this->handleReturn([
            'status'        => 'success',
            'description'   => 'Password changed successfully.',
        ]);
    }

    private function handleReturn( array $returnData): void
    {
        header('Content-type: application/json');
        die(json_encode($returnData));
    }
}