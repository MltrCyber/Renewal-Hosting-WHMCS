<?php

namespace WHMCS\Module\Addon\ClientPassword\Helpers;

if(session_status() == PHP_SESSION_NONE){
    session_start();
}

class CsrfHelper
{
    public static function generate($key): string
    {
        unset($_SESSION['csrf_' . $key]);
        return $_SESSION['csrf_' . $key] = sha1(bin2hex(random_bytes(128) . time()));
    }

    public static function verify($key, $token): bool
    {
        return $token === $_SESSION['csrf_' . $key];
    }
}