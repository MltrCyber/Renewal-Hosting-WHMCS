<?php

use Exception;
use WHMCS\Authentication\CurrentUser;
use WHMCS\Config\Setting as SystemSetting;
use WHMCS\Module\Addon\Setting as AddonSetting;
use WHMCS\Module\Addon\ClientPassword\Helpers\CsrfHelper;

if (!defined('WHMCS')) {
    exit('This file cannot be accessed directly.');
}

add_hook('AdminAreaFooterOutput', 1, function () {
    try {
        $addonSettings = [];
        $currentUser = new CurrentUser;

        AddonSetting::module( 'client_password' )->each( function ( $setting ) use ( &$addonSettings ) {
            $addonSettings[ $setting->setting ] = $setting->value;
        } );

        if ( $currentUser->admin() && !in_array( $currentUser->admin()->roleid, explode( ',', $addonSettings[ 'access' ] ) ) ) {
            return;
        }

        $systemUrl = SystemSetting::getValue( 'SystemURL' );
        $smarty = new Smarty;
        $smarty->caching = false;
        $smarty->setTemplateDir( __DIR__ . '/templates' );
        $smarty->setCompileDir( $GLOBALS[ 'templates_compiledir' ] );

        $moduleLink = $systemUrl . '/' . $GLOBALS[ 'customadminpath' ] . '/addonmodules.php?module=client_password';
        $smarty->assign( [
            'moduleLink' => $moduleLink,
            'csrfToken' => CsrfHelper::generate( $addonSettings[ 'csrfKey' ] ),
            'passwordLength' => $addonSettings[ 'passwordLength' ],
            'useNumbers' => $addonSettings[ 'useNumbers' ],
            'useCapitalLetters' => $addonSettings[ 'useCapitalLetters' ],
            'useSpecialCharacters' => $addonSettings[ 'useSpecialCharacters' ],
        ] );

        return $smarty->fetch( 'modal.tpl' );
    } catch (Exception $e) {
        return;
    }
});